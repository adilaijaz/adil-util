/*  Copyright 1982 Gary Perlman */

/*LINTLIBRARY*/
#include "stat.h"
#ifdef __TURBOC__
#include <process.h>
#endif
FUN(random,random number initialization,5.2,12/21/86)

double	Maxrand;
#define	MAX32 2147483648.0
#define	MAX16 32768.0
#define MAXRAND (sizeof (int) == 4 ? MAX32 : MAX16)

initrand (seed)
int 	seed;
	{
	long 	clock;
	if (seed == 0)
		{
		time (&clock);
		seed = clock + getpid ();
		}
	srand (seed);
	Maxrand = MAXRAND;
	}
