/* declarations of string functions, with System V and Berkeley names */
extern char
	*strcpy (), *strncpy (),
	*strcat (), *strncat (),
	*strchr (), *strrchr (),         /* System V names */
	*strpbrk (), *strtok (),
	*index (), *rindex ();           /* Berkeley names */
extern int
	strcmp (),
	strncmp (),
	strlen (),
	strspn (), strcspn ();
