char *malloc (), *calloc ();
