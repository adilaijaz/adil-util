/*
   the original linux (and machten unix) atof looks 
   broken.  this is a fix that uses sscanf.  probably
   should add the .o file to /usr/lib/libc.a archive 
   using ar, but I'm hesitant to make that big a change
   to everything just now.

   in meantime, add "double atof();" to your file and 
   use "atof.o" when linking
*/

double atof (word)
char *word;
{ 
  double val;
  sscanf(word,"%lf",&val);
  /*  printf("atof: %lf\n", val);  */
  return(val);
}
